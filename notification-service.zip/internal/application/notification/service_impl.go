package notification

import (
	"context"
	domain "github.com/alimarzban99/notification-service/internal/interfaces/mail"

	"github.com/alimarzban99/notification-service/internal/infrastructure/logger"

	"go.uber.org/zap"
)

type service struct {
	logger logger.Logger
	mailer domain.MailService
}

func NewService(
	log logger.Logger,
	mailer domain.MailService,
) Service {

	return &service{
		logger: log,
		mailer: mailer,
	}
}

func (s *service) SendEmail(
	ctx context.Context,
	input SendEmailInput,
) error {

	s.logger.Info(
		"Application SendEmail",
		zap.String("email", input.Email),
	)

	return s.mailer.Send(
		ctx,
		input.Email,
		input.Subject,
		input.Body,
	)
}

func (s *service) SendProcessingCompleted(
	ctx context.Context,
	input ProcessingCompletedInput,
) error {

	body := "Video " + input.Filename + " has been processed."

	return s.mailer.Send(
		ctx,
		input.Email,
		"Processing Completed",
		body,
	)
}
