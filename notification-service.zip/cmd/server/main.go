package main

import (
	"fmt"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	"github.com/alimarzban99/notification-service/internal/bootstrap"
	httpHandler "github.com/alimarzban99/notification-service/internal/interfaces/http"
)

func main() {

	app, err := bootstrap.New()
	if err != nil {
		log.Fatal(err)
	}

	defer app.Logger.Sync()

	http.HandleFunc("/health", httpHandler.HealthCheck)
	http.Handle("/metrics", promhttp.Handler())

	go http.ListenAndServe(fmt.Sprintf(":%d", app.Config.Server.HttpPort), nil)

	go func() {

		if err := app.GRPC.Start(); err != nil {
			app.Logger.Fatal(err.Error())
		}

	}()

	stop := make(chan os.Signal, 1)

	signal.Notify(
		stop,
		os.Interrupt,
		syscall.SIGTERM,
	)

	<-stop

	app.GRPC.Stop()
}
